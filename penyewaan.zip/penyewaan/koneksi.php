<?php

$host='localhost';
	$dbname='persewaan';
	$user='root';
	$pass='';
	
	$con=mysqli_connect($host, $user, $pass, $dbname);
	
?>