<html>
<head>
	<title>PENCARIAN</title>
</head>
<body>
<H2 align="center">PENCARIAN</H2>
<form action = "cari.php" method="POST">	
	<table align="center"; margin="100">
    <tr>
      <td align="right">Masukkan Id Transaksi : </td>
      <td align="left"><input type="text" name="id_transaksi"></td>
    </tr>
	<tr>
    	<td align="right"><input type="submit" value="Cari"></td>
    	<td align="left"><a href = "index.php"><input type="submit" value="Kembali"></a></td>
    </tr>
		
		</form>
</body>
</html>